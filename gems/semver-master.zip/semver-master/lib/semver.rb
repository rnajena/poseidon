require 'yaml'
require 'xsemver'
require 'semver/semvermissingerror'

class SemVer < ::XSemVer::SemVer
end
