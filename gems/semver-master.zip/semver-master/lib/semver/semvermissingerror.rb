class SemVerMissingError < RuntimeError
end