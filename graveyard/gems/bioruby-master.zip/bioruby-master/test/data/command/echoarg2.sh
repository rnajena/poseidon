#!/bin/sh

/bin/echo "$2"

