Then /^I debug$/ do
  require 'ruby-debug'
  breakpoint
  0
end
