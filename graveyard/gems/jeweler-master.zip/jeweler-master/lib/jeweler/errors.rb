class Jeweler
  # Gemspec related error
  class GemspecError < StandardError
  end

  class VersionYmlError < StandardError
  end
end
