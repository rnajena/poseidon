require 'jeweler/rubygems_tasks'

class Jeweler
  # Deprecated tasks for publishing to Gemcutter. See Jeweler::RubygemsDotOrgTasks
  # for the current tasks to use.
  class GemcutterTasks < RubygemsDotOrgTasks
  end
end
