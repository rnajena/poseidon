require 'example_helper'

describe '<%= constant_name %>' do
  it 'fails' do
    fail 'hey buddy, you should probably rename this file and start specing for real'
  end
end
