require 'helper'

class Test<%= constant_name %> < MiniTest::Test
  def test_something_for_real
    flunk "hey buddy, you should probably rename this file and start testing for real"
  end
end
