#define PACKAGE_NAME "yaml"
#define PACKAGE_TARNAME "yaml"
#define PACKAGE_VERSION "0.1.7"
#define PACKAGE_STRING "yaml 0.1.7"
#define PACKAGE_BUGREPORT "https://github.com/yaml/libyaml/issues"
#define PACKAGE_URL "https://github.com/yaml/libyaml"
#define YAML_VERSION_MAJOR 0
#define YAML_VERSION_MINOR 1
#define YAML_VERSION_PATCH 7
#define YAML_VERSION_STRING "0.1.7"
